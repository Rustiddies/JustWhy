# WhyMessenger 2.0

![WhyMessenger](whymessenger-logo.png)
Discord-style messenger: nav rail, DM sidebar, search-first discovery, recent conversations, emoji + colour avatars, favicon. Stack: HTML, CSS, vanilla JS, Firebase Auth + Firestore (SDK 10.12.2). Free Spark plan; no Storage needed. Run with VS Code Live Server.

## Setup
1. Paste your Firebase config into `app.js`.
2. Firestore Database → Rules → replace everything with `firestore.rules` → **Publish** (required; without it Recent conversations and profile saving fail with "permission denied").
3. Open `index.html` with Live Server, hard-refresh (Ctrl+Shift+R).

## Behaviour
- No user directory is shown. Search by name or email (2+ characters, case-insensitive, matches anywhere) and click a result to open a chat; the chat document is created only then.
- Recent conversations lists chats you belong to (photo/avatar, name, last message, time). Older chats show "No messages yet" until a new message is sent.
- Profile dialog (bottom-left or gear): choose an emoji and colour, change display name; email is read-only.
- Signed-in users can see other users' name, email and avatar; messages are visible only to the two participants.

## Test checklist
Register → people list is empty → search a user → open chat → send messages in two browsers → refresh (history and Recent persist) → change avatar/name, log out/in → narrow window (<760px) for mobile layout → check tab icon.

## Limitations
Search loads up to 300 profiles and filters in the browser (fine for a prototype); no read receipts, message deletion or photo upload.

## Google sign-in, Hugging Face and Vercel
- **Google sign-in:** Firebase → Authentication → Sign-in method → enable **Google**. Add your Vercel domain under Authentication → Settings → Authorized domains.
- **Hugging Face (AI tone):** the chat header's "AI tone" button loads a Hugging Face sentiment model (Transformers.js, `Xenova/distilbert-base-uncased-finetuned-sst-2-english`) in the browser. It runs on the user's device, needs no server or API key, and message text is never sent to Hugging Face. The first use downloads the model (roughly 70-110 MB) and caches it.
- **Vercel:** static site, no build. Put `index.html`, `style.css`, `app.js`, `favicon.svg` (and optionally `firestore.rules`) at the root of a GitHub repo, import it in Vercel with the "Other" preset and deploy.

## Logo assets
`whymessenger-logo.png` (supplied logo, unchanged), `whymessenger-mark.png` (emblem cropped from it) and `favicon.ico`. Upload the `assets` folder itself to GitHub/Vercel so the paths stay `...`.
